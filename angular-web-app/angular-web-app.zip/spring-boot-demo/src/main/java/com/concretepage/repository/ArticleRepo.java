package com.concretepage.repository;

public class ArticleRepo {
}
